#include "scheduler.h"
 
int RoundRobin(const int& curTime, const vector<Process>& procList, const int& timeQuantum)
{

  static int timeToNextSched = 0;  //keeps track of when we should actually schedule a new process
  static deque<int> ready;  //keeps track of the processes that are ready to be scheduled
  static int selection = -1;
  
  for(int i = 0; i<static_cast<int>(procList.size()); i++)
  {
    if(procList[i].startTime == curTime)
      ready.push_back(i);
  }
// this is a bit of code you might find useful for debuging
//  for(auto& x : ready)
//  {
//    cout << x << " ";
//  }
//  cout << endl;

  // for if process selected is done
  if(selection != -1)
  {
    if(procList[selection].isDone == true)
    {
      selection = -1;
      timeToNextSched = timeQuantum;
      if(ready.size() != 0)
      {
        selection = ready[0];
        ready.pop_front();
      }
      else
      {
        timeToNextSched = 0;
      }
    }
  }

  // for if it is time to do a new schedule
  if(timeToNextSched == 0)
  {
    // if the selection is not -1 then we can just do this
    if(selection != -1)
    {
      ready.push_back(selection);
      selection = ready[0];
      ready.pop_front();
      timeToNextSched = timeQuantum;
    }
    // if the selection is -1 then we should check if there is anything that we could put there instead.
    else if(ready.size() > 0)
    {
      selection = ready[0];
      ready.pop_front();
      timeToNextSched = timeQuantum;
    }
  }
  // if timeToNextSchedule is a positive number then decrement it once per time step.
  if(timeToNextSched > 0)
  {
    timeToNextSched--;
  }
  // return selection could be a positive number within the size of the procList or -1.
  return selection;
}

vector<int> ShortestProcessNext(const int& currentTime, const vector<Process>& procList,int maxNumProcessors)
{
    //should use maxNumProcesses
    static vector<int> readyList; //list of ready processes 
    int index=-1;//index of the next process
    int shortest; //minimal process time
    static int index2=0; //index of previous process

    //Add processes who have arrived onto readyList 
    for (unsigned int i=0; i<procList.size(); i++)
    {
        if (procList[i].startTime==currentTime)
        {
            readyList.push_back(i);
        }
    }
    
    //make sure something is on the readyList
    if (readyList.size()>0)
    {
        index=readyList[index2];
        //see if the process is completed
        if (procList[readyList[index2]].isDone)
        {
            //erase the previous process and find the next shortest 
            readyList.erase(readyList.begin()+index2);
            index2=0;
            index=readyList[0];
            shortest=procList[readyList[0]].totalTimeNeeded;

            for (unsigned int i=1; i<readyList.size(); i++)
            {
            //see if the remaining time of the current process is shorter than the shortest time
                if (procList[readyList[i]].totalTimeNeeded<shortest)
                {
                    shortest=procList[readyList[i]].totalTimeNeeded;
                    index=readyList[i];
                    index2=i;
                }
            }
        }
    }
    return readyList;
//    return index;
}

int ShortestRemainingTime(const int& currentTime, const vector<Process>& procList)
{
    static vector<int> readyList; //list of ready processes
    int index=-1; //index of the next process
    int shortest; //minimal process time
    int timeRemaining; //current time remaining for process
    static int index2=0; //index of the previous process

    //add processes who've arrived onto readyList
    for (unsigned int i = 0; i<procList.size(); i++)
    {
        if (procList[i].startTime==currentTime)
        {
            readyList.push_back(i);
        }
    }

    //make sure there is a process on readyList
    if (readyList.size()>0)
    {
        //see if process is completed.
        if (procList[readyList[index2]].isDone==true)
        {
            //erase previous and find the next shortest
            readyList.erase(readyList.begin()+index2);
            index2=0;
        }    

        index=readyList[index2];
        shortest=(procList[readyList[index2]].totalTimeNeeded-procList[readyList[index2]].timeScheduled);

        for (unsigned int i=0; i<readyList.size(); i++)
        {
            timeRemaining=(procList[readyList[i]].totalTimeNeeded-procList[readyList[i]].timeScheduled);
            //see if the remaining time of the current process is shorter than the shortest time
            if (timeRemaining<shortest)
            {
                shortest=timeRemaining;
                index=readyList[i];
                index2=i;
            }
        }
    }

    return index;
}

int HighestResponseRatioNext( const int& currentTime, const vector<Process>& procList )
{
    static vector<int> readyList;//list of ready processes
    int index=-1; //index of the next process
    static int index2=0;//index of previous process
    float ratio; //waitTime plus timeNeeded divided by timeNeeded
    float highestRatio; //highest ratio of ready processes
    
    //add arrived processes to readyList
    for (unsigned int i=0; i<procList.size(); i++)
    {
        if (procList[i].startTime==currentTime)
        {
            readyList.push_back(i);
        }
    }

    //make sure there is a process on the readyList
    if (readyList.size()>0)
    {
        index=readyList[index2];
        //make sure the process is complete 
        if (procList[readyList[index2]].isDone)
        {
            //erase the previous process and find the highest ratio
            readyList.erase(readyList.begin()+index2);
            index2=0;
            index=readyList[0];
            highestRatio=(static_cast<float>((currentTime-procList[index].startTime))/procList[index].totalTimeNeeded)+1;

            for (unsigned int i = 1; i < readyList.size(); i++ )
            {
                ratio=(static_cast<float>((currentTime-procList[readyList[i]].startTime))/procList[readyList[i]].totalTimeNeeded)+1;

                //see if current ratio is lower than the ratio of remaining process 
                if (ratio>highestRatio)
                {
                    highestRatio=ratio;
                    index=readyList[i];
                    index2=i;
                }
            }
        }
    }

    return index;
}

#!/bin/bash

cd Diff/
COUNTP=0
#option 2
COUNTTP=0
#option 3
COUNTHP=0
#option 4
COUNTFP=0

#stats
COUNTS=0
#option 2
COUNTTS=0
#option 3
COUNTHS=0
#option 4
COUNTFS=0

for files in *.txt; do
    echo "Checking $files"
    ##wc -c $files | awk '{print $1}'
    c=$( wc -c $files | awk '{print $1}')
    o=$( expr substr $files 7 1)
    i=$( expr substr $files 8 1)
    if [ $c -eq 0 ]; then
        echo "Passed"
        if [ $i = "P" ]; then
            COUNTP=$((COUNTP+1))
            if [ $o -eq 2 ]; then
                COUNTTP=$((COUNTTP+1))
            fi
            if [ $o -eq 3 ]; then
                COUNTHP=$((COUNTHP+1))
            fi
            if [ $o -eq 4 ]; then
                COUNTFP=$((COUNTFP+1))
            fi
        fi
        if [ $i = "S" ]; then
            COUNTS=$((COUNTS+1))
            if [ $o -eq 2 ]; then
                COUNTTS=$((COUNTTS+1))
            fi
            if [ $o -eq 3 ]; then
                COUNTHS=$((COUNTHS+1))
            fi
            if [ $o -eq 4 ]; then
                COUNTFS=$((COUNTFS+1))
            fi    
        fi
    else
        echo "FAILED"
    fi
done
cd ..
cd ..
echo "Total Processing Score: $((100*$COUNTP/21))%" > grade.txt
echo "Total Statisitcs Score: $((100*$COUNTS/21))%" >> grade.txt
echo "" >> grade.txt
echo "Processing Scores:" >> grade.txt
echo "Shortest Process Next Score: $((100*$COUNTTP/7))%" >> grade.txt
echo "Shortest Remaining Time Score: $((100*$COUNTHP/7))%" >> grade.txt
echo "Highest Response Ratio Next Score: $((100*$COUNTFP/7))%" >> grade.txt
echo "" >> grade.txt
echo "Statistics Scores: note if it doesn't process correctly then it will not have correct statistics, if you are sure you statistics are correct please dm Austen so he can check it." >> grade.txt
echo "Shortest Process Next Score: $((100*$COUNTTS/7))%" >> grade.txt
echo "Shortest Remaining Time Score: $((100*$COUNTHS/7))%" >> grade.txt
echo "Highest Response Ratio Next Score: $((100*$COUNTFS/7))%" >> grade.txt
echo "" >> grade.txt
echo "If everything isn't a 100 then check the Diff folder it means that one of your outputs was different than the sample outputs. 2 is spn, 3 is srt, and 4 is hrrn" >> grade.txt
echo "RoundRobin is not for your grade." >> grade.txt
#!/bin/bash
rm -r IO/Diff/*.txt
for files in IO/Inputs/*.txt; do
    o=$( expr substr $files 22 1)
    echo "2"|timeout 40 ./program $files 1 > "IO/StudentsOutputs/outputs${o}_2.txt"
    echo "3"|timeout 40 ./program $files 1 > "IO/StudentsOutputs/outputs${o}_3.txt"
    echo "4"|timeout 40 ./program $files 1 > "IO/StudentsOutputs/outputs${o}_4.txt"
    wcCount=0 #empty line count

done


for files in IO/Outputs/*.txt; do
    wcCount=0
    o=$( expr substr $files 25 1)
    i=$( expr substr $files 27 1)
    while read line; do
            #after 4 empty we start saving lines
            if [ $wcCount -ge 4 ]; then
                #if less than 6 empty lines then this processing lines if more than statistics 
                if [ $wcCount -le 6 ]; then
                    echo "$line" >> "IO/Diff/temp${o}_${i}.a" #processing
                else
                    echo "$line" >> "IO/Diff/temp${o}_${i}.ab" #statistics
                fi
            fi 
            if [ -z "$line" ]; then
                wcCount=$((wcCount+1))
            fi
    done < "$files"
done

for files in IO/StudentsOutputs/*.txt; do
    wcCount=0
    o=$( expr substr $files 27 1)
    i=$( expr substr $files 29 1)
    while read line; do
            #after 4 empty we start saving lines
            if [ $wcCount -ge 4 ]; then
                #if less than 6 empty lines then this processing lines if more than statistics 
                if [ $wcCount -le 6 ]; then
                    echo "$line" >> "IO/Diff/temp${o}_${i}.b" #processing
                else
                    echo "$line" >> "IO/Diff/temp${o}_${i}.bb" #statistics
                fi
            fi 
            if [ -z "$line" ]; then
                wcCount=$((wcCount+1))
            fi
    done < "$files"
done

for files in IO/Diff/*.a; do
    o=$( expr substr $files 1 15)
    i=$( expr substr $files 13 3)
    diff $files "${o}.b" > "IO/Diff/diff${i}P.txt"
done
rm -r IO/Diff/*.a
rm -r IO/Diff/*.b
for files in IO/Diff/*.ab; do
    o=$( expr substr $files 1 15)
    i=$( expr substr $files 13 3)
    diff $files "${o}.bb" > "IO/Diff/diff${i}S.txt"
done
rm -r IO/Diff/*.ab
rm -r IO/Diff/*.bb

cd IO/
sh grader.sh
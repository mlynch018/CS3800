# Multiprocessor Scheduler Showdown
# Programming Assignment Number 2
### Goals

For this assignment you are going to be implementing a few OS scheduling algorithms and comparing their performance given different types of process loads and/or different number of processors. Your program must be able to read in a txt file, run the scheduling algorithm, and give a report of the statistics. The code to run your algorithms is provided.

### File Template
First line is number of processes. All lines after are in the order of process id, start time, and total time needed.

### Running the autograde on you linux machine. 
If you have a linux machine then you can use the command
```
sh diff.sh
```
The script will generate your codes outputs using the different scheduling algorithms, a diff between your outputs and the sample outputs, and a grade.txt. The grade .txt will basically tell you the grade you should expect. When I am grading this on my side I will add another input file for quality check. the 0_2, 0_3, and all outputs tell you what sample input was used and the second number tells you the option used: 2 SPN, 3 SRT, and 4 HRRN.
NOTE: Do not use this on a campus linux machine but feel free to use it on your own machine. When you upload your code to git-classes then it will run the script anyways so no worries. :)

### Algorithms Used
The algorithms used are Round Robin(RR), Shortest Process Next(SPN), Shortest Remaining Time(SRT), and Highest Response Ratio Next(HRRN). For this assignment you will need to implement the SPN, SRT, and HRRN. You might find the round robin useful for getting started but note these algorithms do work differently so it will not be a copy paste.

SPN will be the multiprocessor one you might find that SRT will work similar in some basic logic. Hint you will find it wise to use static with the "Next" algorithms. Also for HRRN you will want to use float for storing the Response Ratios, I advice casting everything related to the ratio calculation as a float to prevent yourself from generating different results. 

You will find it helpful to look over some [C++ documentation](https://www.cplusplus.com/). If you find something in a different version of C++ that you really want to use for this assignment please tell the graders and adjust your makefile to compile with your desire version of C++. If you need help with this you can ask the graders about makefiles. 

#### Example Input
```
2
A 0 5
B 10 2
```
This would run like this for practically any algorithm you used note for option 2 it would print a 2 instead o
### Example Running
```
~/Scheduling Assignment$ make
g++ -W -Wall -pedantic-errors -g -std=c++17  *.cpp -lpthread -o program
~/Scheduling Assignment$ ./program example.txt 1

Welcome to the scheduler simulator

File Name: example.txt
Simulation Speed: 1 milliseconds

What scheduler would you like to test?

1) Round Robin
2) Shortest Process Next 2 at a time
3) Shortest Remaining Time
4) Highest Response Ratio Next

--> 3

Starting simulation
   O: Process scheduled
   X: Process completed
   !: Completed process scheduled more time than needed

Time |    A |    B | IDLE |
---------------------------
   0 |   O  |      |      |
   1 |   O  |      |      |
   2 |   O  |      |      |
   3 |   O  |      |      |
   4 |   X  |      |      |
   5 |      |      |   1  |
   6 |      |      |   1  |
   7 |      |      |   1  |
   8 |      |      |   1  |
   9 |      |      |   1  |
  10 |      |   O  |      |
  11 |      |   X  |      |


Run Statistics:
Process | Finish Time | Turnaround Time | Normalized Turnaround Time |
----------------------------------------------------------------------
      A |           5 |               5 |                       1.00 |
      B |          12 |               2 |                       1.00 |
----------------------------------------------------------------------
   Mean |             |            3.50 |                       1.00 |
```